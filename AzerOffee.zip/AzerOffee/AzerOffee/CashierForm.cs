﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AzerOffee.Model;

namespace AzerOffee
{
    public partial class CashierForm : Form
    {
        private readonly AzerOffeeEntities _context;
        private readonly User _loggedUser;
        private readonly List<OrderDetail> _orderDetails;

        public CashierForm(User user)
        {
            InitializeComponent();
            _context = new AzerOffeeEntities();
            _loggedUser = user;
            _orderDetails = new List<OrderDetail>();
        }

        private void CashierForm_Load(object sender, EventArgs e)
        {
            //Show cashier name for welcoming
            txtWelcome.Text = $"Dear {_loggedUser.Firstname} {_loggedUser.Lastname}, Welcome.";
            UpdateCategoriesCombo();
            cmbCount.SelectedIndex = 0;

        }

        private void UpdateCategoriesCombo()
        {
            cmbCategories.Items.AddRange(_context.Categories.ToArray());
            cmbCategories.SelectedIndex = 0;
        }

        private void cmbCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbItems.Items.Clear();
            Category selectedCategory = cmbCategories.SelectedItem as Category;
            cmbItems.Items.AddRange(selectedCategory.Products.ToArray());
            cmbItems.SelectedIndex = 0;
        }

        private void cmbItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            Product selectedProduct = cmbItems.SelectedItem as Product;
            txtItemPrice.Text = selectedProduct.Price + " AZN";
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            Product selectedProduct = cmbItems.SelectedItem as Product;
            int count = int.Parse(cmbCount.SelectedItem.ToString());

            if(_orderDetails.Any(d => d.Product.Id == selectedProduct.Id))
            {
                _orderDetails.First(d => d.Product.Id == selectedProduct.Id).Count = count;
            }
            else
            {
                _orderDetails.Add(new OrderDetail { Product = selectedProduct, Count = count });
            }
            UpdateItemButtons();
        }

        private void UpdateItemButtons()
        {
            pnlOrderItems.Controls.Clear();
            decimal? totalPrice = 0;

            foreach (var item in _orderDetails)
            {
                //update buttons
                Button btn = new Button();
                btn.Text = $"{item.Product.Name} - {item.Count}";
                btn.BackColor = Color.Orange;
                btn.FlatStyle = FlatStyle.Flat;
                btn.Font = new Font("Century Gothic", 10.75F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(0)));
                btn.ForeColor = SystemColors.ControlLightLight;
                btn.Name = "btnLogin";
                btn.Size = new Size(150, 50);
                btn.UseVisualStyleBackColor = false;

                btn.Click += (sender, e) =>
                {
                    _orderDetails.Remove(item);
                    pnlOrderItems.Controls.Remove(btn);

                    totalPrice -= item.Product.Price * item.Count;
                    txtTotalPrice.Text = $"{totalPrice} AZN";
                };

                pnlOrderItems.Controls.Add(btn);

                //update total price
                totalPrice += item.Product.Price * item.Count;
            }

            pnlOrderItems.Visible = true;
            lblPanelLabel.Visible = true;
            txtTotalPrice.Text = $"{totalPrice} AZN";
        }

        private async void btnFinishOrder_Click(object sender, EventArgs e)
        {
            string customerName = txtCustomerName.Text.Trim();

            if(_orderDetails.Count > 0)
            {
                #region With Task.Run
                //var task = Task.Run(() =>
                //{
                //    PendingsOrder order = _context.PendingsOrders.Add(new PendingsOrder
                //    {
                //        UserId = _loggedUser.Id,
                //        Date = DateTime.Now,
                //        CustomerName = customerName
                //    });

                //    return order;
                //});

                //await task;
                #endregion

                PendingsOrder order = _context.PendingsOrders.Add(new PendingsOrder
                {
                    UserId = _loggedUser.Id,
                    Date = DateTime.Now,
                    CustomerName = customerName
                });

                await _context.SaveChangesAsync();

                foreach (var item in _orderDetails)
                {
                    _context.OrderDetails.Add(new Model.OrderDetail
                    {
                        ProductId = item.Product.Id,
                        Count = item.Count,
                        PendingOrderId = order.Id
                    });
                }

                await _context.SaveChangesAsync();

                ShowMessage("Success", "New order is added to the list Pending Orders", false);
            }
        }

        private class OrderDetail
        {
            public Product Product { get; set; }
            public int Count { get; set; }
        }

        private void ShowMessage(string title, string content, bool isError = true)
        {
            MessageBox.Show(
                content,
                title,
                MessageBoxButtons.OK,
                isError ? MessageBoxIcon.Error : MessageBoxIcon.Information);
        }
    }
}
